@extends('template.app')

<!-- link css external -->
@section('custom-css')

@endsection

<!-- Coding HTML sini gais -->
@section('content')

@endsection

<!-- Script javascriptnya disini gais -->
@section('custom-js')
<script>

</script>
@endsection