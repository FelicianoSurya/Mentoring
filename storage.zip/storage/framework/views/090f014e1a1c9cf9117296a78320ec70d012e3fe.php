

<!-- link css external -->
<?php $__env->startSection('custom-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/about.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Ini halaman about us</h1>
<?php $__env->stopSection(); ?>


<!-- Script javascriptnya disini gais -->
<?php $__env->startSection('custom-js'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GitHub\Mentoring\resources\views/page/about.blade.php ENDPATH**/ ?>